
document.addEventListener('DOMContentLoaded', () => {
    const content = document.getElementById('content');
    let page = 1;

    const loadMorePosts = () => {
        fetch(`https://api.example.com/posts?page=${page}`)
            .then(response => response.json())
            .then(data => {
                data.posts.forEach(post => {
                    const postDiv = document.createElement('div');
                    postDiv.classList.add('post');
                    postDiv.textContent = post.title;
                    content.appendChild(postDiv);
                });
                page++;
            });
    };

    window.addEventListener('scroll', () => {
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
            loadMorePosts();
        }
    });

    // Initial load
    loadMorePosts();
});
    